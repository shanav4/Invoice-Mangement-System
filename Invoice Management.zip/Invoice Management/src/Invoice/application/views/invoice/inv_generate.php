<body>
    <div class="container content-invoice">
        <div class="row">
            <?php echo anchor('InvoiceController/invoice/all', 'View Generated Invoices'); ?>
        </div>
        <form id="invoice-form" method="post" class="invoice-form" role="form" novalidate="">
            <div class="row">
                <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                    <h4>From,</h4>
                    <?php echo $_SESSION['user']; ?><br>
                    <?php echo $_SESSION['address']; ?><br>
                    <?php echo $_SESSION['mobile']; ?><br>
                    <?php echo $_SESSION['email']; ?><br>
                </div>
                <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4 pull-right">
                    <h4>To,</h4>
                    <div class="form-group">
                        <input type="text" class="form-control" name="companyName" id="companyName" placeholder="Company Name" autocomplete="off">
                    </div>
                    <div class="form-group">
                        <textarea class="form-control" rows="3" name="address" id="address" placeholder="Your Address"></textarea>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <table class="table table-bordered table-hover" name="cart">
                    <tr>
                        <th width="2%"><input id="checkAll" class="formcontrol" type="checkbox"></th>
                        <th width="10%">Item No</th>
                        <th width="15%">Item Name</th>
                        <th width="12%">Quantity</th>
                        <th width="15%">Unit Price($)</th>
                        <th width="12%">Tax(%)</th>
                        <th width="15%">Total($)</th>
                    </tr>

                    <tr class="line_items">
                        <td><input class="itemRow" type="checkbox" name='record'></td>
                        <td><input type="text" name="productCode" class="form-control productCode" autocomplete="off"></td>
                        <td><input type="text" name="productName" class="form-control productName" autocomplete="off"></td>
                        <td><input type="number" name="quantity"  class="form-control quantity" autocomplete="off"></td>
                        <td><input type="number" name="price" class="form-control price" autocomplete="off"></td>
                        <td>
                        <select name="tax"  class="form-control tax" autocomplete="off">
                            <option value=".01">1%</option>
                            <option value=".05">5%</option>
                            <option value=".10">10%</option>
                            <option selected value=".00">Tax Free</option>
                        </select><input type="hidden" class="tax_value" name="tax_value" jAutoCalc="{tax} * {total}">
                        </td>
                        <td><input type="text" name="total" class="form-control total" autocomplete="off" jAutoCalc="{quantity} * {price}"></td>
                    </tr>

                    <tr class="line_items">
                        <td><input class="itemRow" type="checkbox" name='record'></td>
                        <td><input type="text" name="productCode" class="form-control productCode" autocomplete="off"></td>
                        <td><input type="text" name="productName" class="form-control productName" autocomplete="off"></td>
                        <td><input type="number" name="quantity"  class="form-control quantity" autocomplete="off"></td>
                        <td><input type="number" name="price" class="form-control price" autocomplete="off"></td>
                        <td>
                        <select name="tax"  class="form-control tax" autocomplete="off">
                            <option value=".01">1%</option>
                            <option value=".05">5%</option>
                            <option value=".10">10%</option>
                            <option selected value=".00">Tax Free</option>
                        </select><input type="hidden" class="tax_value" name="tax_value" jAutoCalc="{tax} * {total}">
                        </td>
                        <td><input type="text" name="total" class="form-control total" autocomplete="off" jAutoCalc="{quantity} * {price}"></td>
                    </tr>

                    <tr class="line_items">
                        <td><input class="itemRow" type="checkbox" name='record'></td>
                        <td><input type="text" name="productCode" class="form-control productCode" autocomplete="off"></td>
                        <td><input type="text" name="productName" class="form-control productName" autocomplete="off"></td>
                        <td><input type="number" name="quantity"  class="form-control quantity" autocomplete="off"></td>
                        <td><input type="number" name="price" class="form-control price" autocomplete="off"></td>
                        <td>
                        <select name="tax"  class="form-control tax" autocomplete="off">
                            <option value=".01">1%</option>
                            <option value=".05">5%</option>
                            <option value=".10">10%</option>
                            <option selected value=".00">Tax Free</option>
                        </select><input type="hidden" class="tax_value" name="tax_value" jAutoCalc="{tax} * {total}">
                        </td>
                        <td><input type="text" name="total" class="form-control total" autocomplete="off" jAutoCalc="{quantity} * {price}"></td>
                    </tr>
        
                    <tr>
                        <td colspan="3">&nbsp;</td>
                        <td>Subtotal($)</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td><input type="text" id="subTotal" name="subTotal" class="form-control subTotal" value="" jAutoCalc="SUM({total})"></td>
                    </tr>
                    <tr>
                        <td colspan="3">&nbsp;</td>
                        <td>Tax Amount($)</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td><input type="text" id="taxAmount" name="taxAmount" class="form-control taxAmount" value="" jAutoCalc="SUM({tax_value})"></td>
                    </tr>
                    <tr>
                        <td colspan="3">&nbsp;</td>
                        <td>Total including tax($)</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td><input type="text" id="totalAftertax" name="totalAftertax" class="form-control totalAftertax" value="" jAutoCalc="{subTotal} + {taxAmount}"></td>
                    </tr>

                    <tr>
                        <td colspan="3">&nbsp;</td>
                        <td>Discount($)</td>
                        <td>
                        <select name="discount_type" id="discount_type" class="form-control discount_type" autocomplete="off" onchange="showDiscountPercentage();">
                            <option value="1">Percentage</option>
                            <option selected value="0">Amount</option>
                        </select>
                        </td>
                        <td><input style="display: none;" id="discount_amt" type="text"  class="form-control"  placeholder="Discount Amt($)" onchange="calculate_discount(0)">

                        <input style="display: none;" type="text" id="discount_per" class="form-control"  placeholder="Discount Percentage(%)" onchange="calculate_discount(1)">
                        </td>
                        <td><input type="text" id="discount" name="discount" class="form-control discount" value="0.00" readonly>
                        </td>
                    </tr>

                    <tr>
                        <td colspan="3">&nbsp;</td>
                        <td>Grand Total($)</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td><input type="text" id="totalAmount" name="totalAmount" class="form-control totalAmount" value="" jAutoCalc="{totalAftertax} - {discount}"></td>
                    </tr>
                </table>

            </div>
        </div>

        <div class="row">
            <div class="col-xs-12 col-sm-3 col-md-3 col-lg-3">
                <button class="btn btn-danger delete" id="removeRows" type="button">- Delete</button>
                <button class="btn btn-success row-add" id="addRows" type="button">+ Add More</button>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
                <h3>Notes: </h3>
                <div class="form-group">
                    <textarea class="form-control txt" rows="5" name="notes" id="notes" placeholder="Your Notes"></textarea>
                </div>
                <div class="form-group">
                    <input type="hidden" value="<?php echo $_SESSION['userid']; ?>" class="form-control" name="userId">
                    <input type="button" id="invoice_btn" name="invoice_btn" value="Generate Invoice" class="btn btn-success submit_btn invoice-save-btm">
                </div>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript">
    function showDiscountPercentage(){
           document.getElementById("discount_per").style.display="none";
           document.getElementById("discount_amt").style.display="none";
           var e = document.getElementById("discount_type");
           var dis_type = e.options[e.selectedIndex].value;
           //Amount
           if(dis_type == 0) {
            document.getElementById("discount_amt").style.display="";
           }
           else if(dis_type == 1) {
           document.getElementById("discount_per").style.display="";
           }
        }

        function calculate_discount(type){
            var v;
            var total_after_tax;
            var dis_amt;
            if(type == 0){
                v = parseFloat($('#discount_amt').val());
                $('#discount').val(v);
            }
            else if(type == 1){
                v = parseFloat($('#discount_per').val());
                total_after_tax = $('#totalAftertax').val();
                var total = parseFloat(total_after_tax.replace(/,/g, '')) * v;
                dis_amt = total/100;
                $('#discount').val(dis_amt);
            }
        }
</script>











