<?php 

foreach($records as $r) { 
    
    $order_id = $r->order_id;
    $order_receiver_name = $r->order_receiver_name;
    $order_receiver_address = $r->order_receiver_address;
    $sub_total = $r->order_total_before_tax;
    $tax_amt = $r->order_total_tax;
    $order_total_after_tax = $r->order_total_after_tax;
    $discount = $r->order_discount;
    $grand_total = $r->order_amount_grand_total;
    $note = $r->note;
    $date = $r->order_date;
}
?>

<body>
    <div class="container content-invoice">
        <div class="row">
            <?php echo anchor('InvoiceController/invoice/all', 'View Generated Invoices'); ?>
        </div>
        <form action="" id="invoice-form" method="post" class="invoice-form" role="form" novalidate="">
            <div class="row">
                <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                    <h4>From,</h4>
                    <?php echo $_SESSION['user']; ?><br>
                    <?php echo $_SESSION['address']; ?><br>
                    <?php echo $_SESSION['mobile']; ?><br>
                    <?php echo $_SESSION['email']; ?><br>
                </div>
                <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4 pull-right">
                    <h4>To,</h4>
                    <div class="form-group">
                        <input type="hidden" name="ed_order_id" id="ed_order_id" value="<?php echo $order_id; ?>">
                        <input type="text" class="form-control ed_company_name" name="ed_company_name" id="ed_company_name" placeholder="Company Name" autocomplete="off" value="<?php echo $order_receiver_name;?>">
                    </div>
                    <div class="form-group">
                        <textarea class="form-control ed_address" rows="3" name="ed_address" id="ed_address" placeholder="Your Address"><?php echo $order_receiver_address;?></textarea>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <table class="table table-bordered table-hover" id="invoiceItem">
                        <tbody>
                            <tr>
                                <th width="10%">Item No</th>
                                <th width="15%">Item Name</th>
                                <th width="15%">Quantity</th>
                                <th width="15%">Unit Price(in $)</th>
                                <th width="10%">Tax(%)</th>
                                <th width="15%">Total</th>
                            </tr>
<?php 
foreach($records as $r) { 
    echo '<tr class="ed_line_items">'; 
    echo "<td><input type='text' name='ed_product_code' class='form-control ed_product_code' autocomplete='off' value='".$r->item_code."'><input type='hidden' name='ed_product_id' class='form-control ed_product_id' autocomplete='off' value='".$r->order_item_id."'></td>";
    echo "<td><input type='text' name='ed_product_name' class='form-control ed_product_name' autocomplete='off' value='".$r->item_name."'></td>";
    echo "<td>".$r->order_item_quantity."</td>";
    echo "<td>".$r->order_item_price."</td>";
    echo "<td>".$r->order_item_tax."</td>";
    echo "<td>".$r->order_item_final_amount."</td>";
    echo "<tr>"; 
    } 
?>
                        </tbody>
                    </table>

                    <table class="table table-bordered table-hover" id="invoiceItem">
                        <tbody>
                            <tr>
                                <th width="10%">Subtotal(in $)</th>
                                <th width="15%">Tax Amount(in $)</th>
                                <th width="15%">Sub Total with tax(in $)</th>
                                <th width="15%">Discount(in $)</th>
                                <th width="10%">Total Amount(in $)</th>
                            </tr>
                            <tr>
                                <td><?php echo $sub_total; ?></td>
                                <td><?php echo $tax_amt; ?></td>
                                <td><?php echo $order_total_after_tax; ?></td>
                                <td><?php echo $discount; ?></td>
                                <td><?php echo $grand_total; ?></td>
                            </tr>
                        </tbody>
                    </table>

                </div>
            </div>

            <div class="row">
            <div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
                <h3>Notes: </h3>
                <div class="form-group">
                    <textarea class="form-control txt ed_notes" rows="5" name="ed_notes" id="ed_notes" placeholder="Your Notes"><?php echo $note; ?></textarea>
                </div>
                <div class="form-group">
                    <input type="hidden" value="<?php echo $_SESSION['userid']; ?>" class="form-control" name="userId">
                    <input type="button" id="up_invoice_btn" name="up_invoice_btn" value="Update Invoice" class="btn btn-success">
                </div>
            </div>
        </div>
        </form>
    </div>
    <script type="text/javascript">
        $(document).ready(function(){
            $("#up_invoice_btn").click(function(){
            var products = [];
            var invoice_details = [];
            var product = {};
            var order_id = $('#ed_order_id').val();
            var pr_code = $('.ed_product_code').val();
            var pr_name = $('.ed_product_name').val();
            var receiver_name = $('#ed_company_name').val();
            var receiver_address = $('#ed_address').val();
            var notes = $('#ed_notes').val();
            if(pr_code!="" && pr_name!="" && receiver_name!="" && receiver_address!="" && notes!="" && order_id!="") {
                
                $('tr.ed_line_items').each(function () {

                    product = {};
                    var self = $(this);
                    var item_no = self.find(".ed_product_code").val().trim();
                    var item_name = self.find(".ed_product_name").val().trim();
                    var pr_id = self.find(".ed_product_id").val().trim();
                    product.id = pr_id;
                    product.item_no = item_no;
                    product.item_name = item_name;
                    products.push(product);
                });

                invoice_details['products'] = products;
                invoice_details['order_id'] = order_id;
                invoice_details['name'] = receiver_name;
                invoice_details['address'] = receiver_address;
                invoice_details['notes'] = notes;

                
                jQuery.ajax({
                    type: "POST",
                    url: "<?php echo base_url('index.php/InvoiceController/update_invoice'); ?>",
                    data: {
                        order_id : invoice_details['order_id'], 
                        name : invoice_details['name'],
                        address : invoice_details['address'],
                        notes : invoice_details['notes'],
                        products : invoice_details['products']
                    },
                    success: function(res) 
                    {
                        
                        if(res == 0) {
                            alert('Database Error!');
                        } else {
                            alert('Successfully updated');
                        var redirect = "<?php echo base_url('index.php/InvoiceController/invoice/'); ?>"+invoice_details['order_id'];
                            $(location).attr("href", redirect); 
                        }
                        
                    },
                    error:function()
                    {
                    alert('Error Occured!');    
                    }
                    });
            


            } else {
                alert("pls fill all fields first");
            }
        });
        });
    </script>


    


