<body>
	<div id="container">
		<div id="body">
			<div class="sidenav" style="height: 100%; width: 25%; align-content: center;">
			  <a href="#">Invoice Management System</a>
			  <a href="#"><img id="avatar" src="<?php echo site_url('../assets/images/avatar.png');?>" width="100px" height="100px"></a>
			  <a href="#"><h4>Dashboard</h4></a>
			  <a href="<?php echo site_url('InvoiceController/generate_invoice')?>"><h4>Generate Invoice</h4></a>
			  <a href="<?php echo site_url('InvoiceController/invoice/all')?>"><h4>View Invoice</h4></a>
			</div>
			<div id="chartContainer" style="height: 100%; width: 70%; margin-left: 30%;"></div>
		</div>
	</div>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
	<script>
	window.onload = function () {
 		var chart = new CanvasJS.Chart("chartContainer", {
			title: {
				text: "Payments received over an year"
			},
			axisY: {
				title: "Payments received (in dollars)"
			},
			data: [{
				type: "line",
				dataPoints: <?php echo json_encode($records, JSON_NUMERIC_CHECK); ?>
			}]
		});
	chart.render();
 	}
	</script>
