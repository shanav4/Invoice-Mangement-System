<body>
    <div class="container content-invoice">
        <form action="" id="invoice-form" method="post" class="invoice-form" role="form" novalidate="">
            <div class="row">
                <?php echo anchor('InvoiceController/generate_invoice', 'Generate Invoice'); ?>
            </div>
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <table class="table table-bordered table-hover" id="invoiceItem">
                        <tbody>
                            <tr>
                                <th width="5%">Sl No</th>
                                <th width="10%">Order Id</th>
                                <th width="15%">Order Date</th>
                                <th width="10%">Order Receiver Name</th>
                                <th width="15%">Order Amount($)</th>
                                <th width="10%">Edit</th>
                                <th width="10%">Delete</th>
                                <th width="10%">Actions</th>
                            </tr>
                            <?php
                            $i = 1;
                            foreach($records as $r) { 
                               echo '<tr>'; 
                               echo '<td>'.$i++.'</td>'; 
                               echo "<td>".$r->order_id."</td>"; 
                               echo "<td>".$r->order_date."</td>";
                               echo "<td>".$r->order_receiver_name."</td>";
                               echo "<td>".$r->order_amount_grand_total."</td>";
                               echo "<td><a href = '".base_url()."index.php/InvoiceController/invoice_edit/"
                                  .$r->order_id."'>Edit</a></td>";
                               echo "<td><a href = '".base_url()."index.php/InvoiceController/invoice_delete/"
                                  .$r->order_id."'>Delete</a></td>";
                               echo "<td><a href = '".base_url()."index.php/InvoiceController/invoice/"
                                  .$r->order_id."'>View Details</a></td>"; 
                               echo "<tr>"; 
                            } 
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </form>
    </div>
    