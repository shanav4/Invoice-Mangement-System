<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
  <head>
  <meta charset="utf-8">
    <title>Invoice management system</title>
    <link rel="stylesheet" type="text/css" href="<?php echo site_url('../assets/css/style.css');?>">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
    <script type="text/javascript" src="<?php echo site_url('../assets/js/jautocalc.js');?>"></script>
    <script type="text/javascript">

    $(function() {

      function autoCalcSetup() {
        $('form#invoice-form').jAutoCalc('destroy');
        $('form#invoice-form tr.line_items').jAutoCalc({keyEventsFire: true, decimalPlaces: 2, emptyAsZero: true});
        $('form#invoice-form').jAutoCalc({decimalPlaces: 2});
      }
      autoCalcSetup();
    });

    $(document).ready(function(){

        document.getElementById("discount_amt").style.display="";
        
        //Add dynamic rows
        $('button.row-add').on("click", function(e) {
        e.preventDefault();
        var $last = $('.line_items').last();
        var $new = $last.clone(true);
        $new.jAutoCalc('destroy');
        $new.insertAfter($last);
        $new.find('input[type=text]').val('');
        autoCalcSetup();
        });

        // Find and remove selected table rows
        $("#removeRows").click(function(){
            $("table tbody").find('input[id="checkAll"]').each(function(){
                if($(this).is(":checked")){
                    var count = $('.itemRow').length;
                    while(count > 1){
                    document.getElementsByTagName("tr")[count].remove();
                    count--;
                    }
                    
            }
            });
            $("table tbody").find('input[name="record"]').each(function(){
                if($(this).is(":checked")){
                var item_count = $('.line_items').length;
                    if(item_count > 1){
                    $(this).parents("tr").remove();
                    }
                }
            });
        });

        //Invoice generation
        
        $("#invoice_btn").click(function(){

            var products = [];
            var invoice_details = [];
            var product = {};
            var item_no = $('.productCode').val();
            var item_name = $('.productName').val();
            var price = $('.price').val();
            var quantity = $('.quantity').val();
            var total = $('.total').val();
            invoice_details['name'] = $('#companyName').val();
            invoice_details['address'] = $('#address').val();
            invoice_details['notes'] = $('#notes').val();
            if(price!="" && quantity!="" && total!="" && item_no!="" && item_name!="" && invoice_details['name']!="" && invoice_details['address']!="" && invoice_details['notes']!="" ) {
                
                $('tr.line_items').each(function () {

                    product = {};
                    var self = $(this);
                    var item_no = self.find(".productCode").val().trim();
                    var item_name = self.find(".productName").val().trim();
                    var quantity = self.find(".quantity").val().trim();
                    var price = self.find(".price").val().trim();
                    var tax = self.find(".tax_value").val().trim();
                    var total = self.find(".total").val().trim();
                    product.item_no = item_no;
                    product.item_name = item_name;
                    product.tax = tax;
                    product.price = price;
                    product.quantity = quantity;
                    product.total = total;
                    products.push(product);
                });

                invoice_details['subTotal'] = $('#subTotal').val();
                invoice_details['taxAmount'] = $('#taxAmount').val();
                invoice_details['totalAftertax'] = $('#totalAftertax').val();
                invoice_details['discount'] = $('#discount').val();
                invoice_details['totalAmount'] = $('#totalAmount').val();
                invoice_details['products'] = products;

                jQuery.ajax({
                    type: "POST",
                    url: "<?php echo base_url('index.php/InvoiceController/create_invoice'); ?>",
                    data: { 
                        name : invoice_details['name'],
                        address : invoice_details['address'],
                        subTotal : invoice_details['subTotal'],
                        taxAmount : invoice_details['taxAmount'],
                        totalAftertax : invoice_details['totalAftertax'],
                        discount : invoice_details['discount'],
                        totalAmount : invoice_details['totalAmount'],
                        notes : invoice_details['notes'],
                        products : invoice_details['products']
                    },
                    success: function(res) 
                    {
                        
                        if(res == 0) {
                            alert('Database Error!');
                        } else {
                            alert('Generated Invoice');
                            var redirect = "<?php echo base_url('index.php/InvoiceController/invoice/'); ?>"+res;
                            $(location).attr("href", redirect);
                        }
                        
                    },
                    error:function()
                    {
                    alert('Error Occured!');    
                    }
                    });
            


            } else {
                alert("pls fill all fields first");
            }
        });
    });
</script>
</head>

<header class="heading">
    <div>
      <a class="brand" href="index.html">Invoice management system</a>
    </div>
    <div>
    <span style="color:yellow"><?php echo 'Welcome '.$this->session->userdata('admin_name'); ?></span>
    <?php echo anchor('InvoiceController/index', 'Dashboard'); ?> 
    <?php echo anchor('InvoiceController/invoice/all', 'Invoice'); ?>
    <?php echo anchor('LoginController/logout', 'Logout'); ?>
    </div>
</header>

  

 
    