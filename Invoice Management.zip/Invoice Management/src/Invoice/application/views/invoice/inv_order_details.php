<?php 

foreach($records as $r) { 
    
    $order_receiver_name = $r->order_receiver_name;
    $order_receiver_address = $r->order_receiver_address;
    $sub_total = $r->order_total_before_tax;
    $tax_amt = $r->order_total_tax;
    $order_total_after_tax = $r->order_total_after_tax;
    $discount = $r->order_discount;
    $grand_total = $r->order_amount_grand_total;
    $note = $r->note;
    $date = $r->order_date;
    
}
?>

<body>
    <div class="container content-invoice">
        <div class="row">
            <?php echo anchor('InvoiceController/invoice/all', 'View Generated Invoices'); ?>
        </div>
        <form action="" id="invoice-form" method="post" class="invoice-form" role="form" novalidate="">
            <div class="row">
                <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                    <h4>From,</h4>
                    <?php echo $_SESSION['user']; ?><br>
                    <?php echo $_SESSION['address']; ?><br>
                    <?php echo $_SESSION['mobile']; ?><br>
                    <?php echo $_SESSION['email']; ?><br>
                </div>
                <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4 pull-right">
                    <h4>To,</h4>
                    <div class="form-group">
                        <?php echo $order_receiver_name;?>
                    </div>
                    <div class="form-group">
                        <?php echo $order_receiver_address;?>
                    </div>
                    </div>
            </div>
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <table class="table table-bordered table-hover" id="invoiceItem">
                        <tbody>
                            <tr>
                                <th width="10%">Item No</th>
                                <th width="15%">Item Name</th>
                                <th width="15%">Quantity</th>
                                <th width="15%">Unit Price(in $)</th>
                                <th width="10%">Tax(%)</th>
                                <th width="15%">Total</th>
                            </tr>
<?php 
foreach($records as $r) { 
    echo '<tr>'; 
    echo "<td>".$r->item_code."</td>";
    echo "<td>".$r->item_name."</td>"; 
    echo "<td>".$r->order_item_quantity."</td>";
    echo "<td>".$r->order_item_price."</td>";
    echo "<td>".$r->order_item_tax."</td>";
    echo "<td>".$r->order_item_final_amount."</td>";
    echo "<tr>"; 
    } 
?>
                        </tbody>
                    </table>

                    <table class="table table-bordered table-hover" id="invoiceItem">
                        <tbody>
                            <tr>
                                <th width="10%">Subtotal(in $)</th>
                                <th width="15%">Tax Amount(in $)</th>
                                <th width="15%">Sub Total with tax(in $)</th>
                                <th width="15%">Discount(in $)</th>
                                <th width="10%">Total Amount(in $)</th>
                            </tr>
                            <tr>
                                <td><?php echo $sub_total; ?></td>
                                <td><?php echo $tax_amt; ?></td>
                                <td><?php echo $order_total_after_tax; ?></td>
                                <td><?php echo $discount; ?></td>
                                <td><?php echo $grand_total; ?></td>
                            </tr>
                        </tbody>
                    </table>

                </div>
            </div>

            <div class="row">
                <div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
                    <h5><p>Order Date: <?php echo date('d-m-Y', strtotime($date));?><p>Notes: <?php echo $note;?></p></p></h5>
                    <div class="form-group">
                        <input type="hidden" value="<?php echo $_SESSION['userid']; ?>" class="form-control" name="userId">
                    </div>
                </div>
            </div>
        </form>
        <button onclick="print_invoice();" class="btn btn-success">Print Invoice</button>
    </div>
    <script type="text/javascript">
    function print_invoice(){
        var restorepage = document.body.innerHTML;
        var printcontent = document.getElementById('invoice-form').innerHTML;
        document.body.innerHTML = printcontent;
        window.print();
        document.body.innerHTML = restorepage;
    }
    </script>
