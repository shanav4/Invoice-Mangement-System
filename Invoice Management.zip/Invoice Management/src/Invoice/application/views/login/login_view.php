<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="<?php echo site_url('../assets/css/style.css');?>">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>
<body bgcolor="<?php echo isset($color) ? $color : ''; ?>">
<h2 class="brand"><?php echo isset($title) ? $title : ''; ?></h2>  
    <form id="login-form" method="post" action="<?php echo site_url('LoginController/process'); ?>">
    <center> 
    <div class="container">
    <br><br><br>
    <label for="user"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="user" required>
    <label for="pass"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="pass" required>
    <input type="submit" id="button" value="Login" class="btn btn-success"><span style="color:red"><?php echo isset($error) ? $error : ''; ?></span>
    </div></center>
    </form>
</body>
</html>
