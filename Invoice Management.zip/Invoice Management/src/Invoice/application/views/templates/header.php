<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
  <head>
  	<meta charset="utf-8">
  	<title>Invoice management system</title>
  	<link rel="stylesheet" type="text/css" href="<?php echo site_url('../assets/css/style.css');?>">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

  	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
  </head>

  <header class="heading">
    <div>
      <a class="brand" href="index.html">Invoice management system</a>
    </div>
    <div>
    <span style="color:yellow"><?php echo 'Welcome '.$this->session->userdata('admin_name'); ?></span>
    <?php echo anchor('InvoiceController/index', 'Dashboard'); ?> 
    <?php echo anchor('InvoiceController/invoice/all', 'Invoice'); ?>
    <?php echo anchor('LoginController/logout', 'Logout'); ?>
    </div>
  </header>

 
    