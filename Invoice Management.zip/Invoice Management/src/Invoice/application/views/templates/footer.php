		<footer class="heading center">
			All rights reserved
		</footer>
	</body>
</html>