<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class InvoiceController extends CI_Controller
{

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct()
	{
		parent::__construct();
		$this->load->database();//loading database
	}

	public function index()
	{
        $this->load->view('templates/header');
        $data['records'] = array(
			array("y" => 340, "label" => "January"),
			array("y" => 15, "label" => "February"),
			array("y" => 25, "label" => "March"),
			array("y" => 5, "label" => "April"),
			array("y" => 10, "label" => "May"),
			array("y" => 0, "label" => "June"),
			array("y" => 20, "label" => "July"),
			array("y" => 20, "label" => "August"),
			array("y" => 20, "label" => "September"),
			array("y" => 300, "label" => "October"),
			array("y" => 200, "label" => "November"),
			array("y" => 20, "label" => "December")
			);
        $this->load->view('invoice/inv_dashboard',$data);
        $this->load->view('templates/footer');
	}

	public function invoice($id)
	{
        $this->load->view('templates/header');
        $data['records'] = $this->Invoice->fetchInvoiceData($id);
    	if($id == 'all') {
    		$this->load->view('invoice/inv_orders',$data);
    	} else {
    		$this->load->view('invoice/inv_order_details',$data);
    	}
    	$this->load->view('templates/footer');
	}

	public function generate_invoice()
	{

		$this->load->view('invoice/inv_header');
		$this->load->view('invoice/inv_generate');
		$this->load->view('templates/footer');
    }

    public function create_invoice()
    {
    	
		$productData = array();
		$invoiceData = array();
		$products = $this->input->post('products');
	
		foreach($products as $product){
		$product_details = array(
		'item_code' => $product['item_no'],
		'item_name' => $product['item_name'],
		'order_item_quantity' => $product['quantity'],
		'order_item_price' => $product['price'],
		'order_item_tax' => $product['tax'],
		'order_item_final_amount' => $product['total']
		);
		array_push($productData, $product_details);	
		}

		$name = $this->input->post('name');
		$address = $this->input->post('address');
		$subTotal = $this->input->post('subTotal');
		$taxAmount = $this->input->post('taxAmount');
		$totalAftertax = $this->input->post('totalAftertax');
		$discount = $this->input->post('discount');
		$totalAmount = $this->input->post('totalAmount');
		$notes = $this->input->post('notes');
		$now = date('Y-m-d H:i:s');
		$invoiceData = array('user_id'=> $_SESSION['userid'],
					  'order_date'=>$now,
					  'order_receiver_name'=> $name,
					  'order_receiver_address'=> $address,
					  'order_total_before_tax' => $subTotal,
					  'order_total_tax' => $taxAmount,
					  'order_total_after_tax' => $totalAftertax,
					  'order_discount' => $discount,
					  'order_amount_grand_total' => $totalAmount,
					  'note' => $notes
					);
		$invoiceDetails = array('product'=>$productData,
								'invoice'=>$invoiceData);
		
		$result = $this->Invoice->createInvoiceData($invoiceDetails);
		if($result!= 0){
			echo $result;	
		} else {
			echo 0;	
		}
	}

	
	public function update_invoice()
    {
    	
		$productData = array();
		$invoiceData = array();
		$products = $this->input->post('products');
		$order_id = $this->input->post('order_id');
	
		foreach($products as $product){
		$product_details = array(
		'order_item_id'=>$product['id'],
		'item_code' => $product['item_no'],
		'item_name' => $product['item_name']
		);
		array_push($productData, $product_details);	
		}

		$name = $this->input->post('name');
		$address = $this->input->post('address');
		$notes = $this->input->post('notes');
		$invoiceData = array(
					  'order_receiver_name'=> $name,
					  'order_receiver_address'=> $address,
					  'note' => $notes
					);
		$invoiceDetails = array(
			'order_id'=>$order_id,
			'product'=>$productData,
			'invoice'=>$invoiceData
		);
		
		$result = $this->Invoice->updateInvoiceData($invoiceDetails);
		if($result!= 0){
			echo $result;	
		} else {
			echo 0;	
		}
	}

	public function invoice_delete($id)
	{

		$result = $this->Invoice->deleteInvoiceData($id);
		if($result) {
			$this->load->view('templates/header');
        	$data['records'] = $this->Invoice->fetchInvoiceData(all);
    		$this->load->view('invoice/inv_orders',$data);
    		$this->load->view('templates/footer');
    		echo "<script type ='text/JavaScript'>";  
    		echo "alert('Successfully Deleted')";  
    		echo "</script>";	
		}else {
		 	echo 0;	
		}

	}

	public function invoice_edit($id)
	{
		$this->load->view('invoice/inv_header');
        $data['records'] = $this->Invoice->fetchInvoiceData($id);
    	$this->load->view('invoice/inv_edit_order_details',$data);
    	$this->load->view('templates/footer');

	}
}
