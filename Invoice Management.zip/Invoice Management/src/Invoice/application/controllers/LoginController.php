<?php  

defined('BASEPATH') OR exit('No direct script access allowed');  
  
class LoginController extends CI_Controller 
{  
      
    public function index()
    {  
        $data['title'] = 'Invoice Management System';
        $data['color'] = '#203040';
        $this->load->view('login/login_view',$data);  
    }  
    
    public function process()
    {  
        $this->session->set_userdata(array('username'=>$this->input->post('user')));
        $this->session->set_userdata(array('password'=>md5($this->input->post('pass'))));
        $uname = $this->session->userdata['username'];
        $pw = $this->session->userdata['password'];
        $where_array = array(
               'email'=> $uname,
               'password'=> $pw
              );
        $table_name = "invoice_user";
        $query = $this->db->get_where($table_name,$where_array);
        if ($query->num_rows() > 0) {
            $row = $query->row();
            $status = $row->admin_status;
            if ($status == 1) {  
                $this->session->set_userdata(array('admin_name'=>$row->first_name));
                //declaring session  
                $this->session->set_userdata(array('user'=>$row->first_name."".$row->last_name));
                $this->session->set_userdata(array('userid'=>$row->id));
                $this->session->set_userdata(array('email'=>$row->email));
                $this->session->set_userdata(array('address'=>$row->address));
                $this->session->set_userdata(array('mobile'=>$row->mobile));
                redirect("InvoiceController");   
            }  
        } else {  
            $data['error'] = 'Your Account is Invalid';  
            $this->load->view('login/login_view', $data);  
        } 
    }  
    
    public function logout()
    {  
        //removing session  
        $this->session->unset_userdata('user');
        $this->session->unset_userdata('username');
        $this->session->unset_userdata('password'); 
        $this->session->unset_userdata('admin_name');
        $this->session->unset_userdata('userid');
        $this->session->unset_userdata('email');
        $this->session->unset_userdata('address');
        $this->session->unset_userdata('mobile'); 
        redirect("LoginController");  
    }  
  
}  
?>  