<?php
class Invoice_model extends CI_Model 
{  
	public function __construct()
	{
		parent::__construct();
		$this->load->database();//loading database
	}

	public function createInvoiceData($data)
	{
		
		$productData = $data['product'];
		$invoiceData = $data['invoice'];
		$query1 = $this->db->insert('invoice_order',$invoiceData);
		if($query1){
			$insert_id = $this->db->insert_id();
			foreach ($productData as $product) {
			$product['order_id'] = $insert_id;
			$query2 = $this->db->insert('invoice_order_item',$product);
			}
			if($query2) {
				return $insert_id;	
			} else {
			return 0;	
		}
		} else{
			return 0;
		}
	}

	
	public function updateInvoiceData($data)
	{
		
		$order_id = $data['order_id'];
		$productData = $data['product'];
		$invoiceData = $data['invoice'];
		if($order_id > 0){
			$this->db->where('order_id',$order_id);
			$query1 = $this->db->update('invoice_order',$invoiceData);
			if($query1){
				foreach ($productData as $product) {
					$array_data = array('item_code' => $product['item_code'], 'item_name' => $product['item_name']);
					$this->db->where('order_item_id',$product['order_item_id']);
					$query2 = $this->db->update('invoice_order_item',$array_data);
					}
				if($query2) {
					return 1;	
					} else {
					return 0;	
					}
				
			} else{
				return 0;
			}

		}
		else{
			return 0;
		}
		
	}
 
	public function fetchInvoiceData($id)
	{
		if($id == 'all') {
        	$query = $this->db->get('invoice_order');
        } else {
    		$this->db->select('*');
		    $this->db->from('invoice_order');
		    $this->db->join('invoice_order_item', 'invoice_order.order_id = invoice_order_item.order_id');
		    $this->db->where(array('invoice_order.order_id' => $id));
 			$query = $this->db->get();
		}
		return($query->result());
	}

	public function deleteInvoiceData($id)
	{
		if($id){
		    $this->db->where(array('invoice_order_item.order_id' => $id));
		    $query1 = $this->db->delete('invoice_order_item');
 			if($query1) {
 				$this->db->where(array('invoice_order.order_id' => $id));
		    	$query2 = $this->db->delete('invoice_order');
		    	if($query2) {
		    		return 1;
		    	} else {
		    		return 0;
		    	}
			} else {
				return 0;
			}

		}
	}
}
?>