-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 17, 2021 at 08:17 AM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `invoice`
--

-- --------------------------------------------------------

--
-- Table structure for table `invoice_order`
--

DROP TABLE IF EXISTS `invoice_order`;
CREATE TABLE IF NOT EXISTS `invoice_order` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `order_date` date NOT NULL,
  `order_receiver_name` varchar(250) NOT NULL,
  `order_receiver_address` text NOT NULL,
  `order_total_before_tax` decimal(10,2) NOT NULL,
  `order_total_tax` decimal(10,2) NOT NULL,
  `order_discount` varchar(250) NOT NULL,
  `order_total_after_tax` double(10,2) NOT NULL,
  `order_amount_grand_total` decimal(10,2) NOT NULL,
  `note` text NOT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoice_order`
--

INSERT INTO `invoice_order` (`order_id`, `user_id`, `order_date`, `order_receiver_name`, `order_receiver_address`, `order_total_before_tax`, `order_total_tax`, `order_discount`, `order_total_after_tax`, `order_amount_grand_total`, `note`) VALUES
(8, 123456, '2021-12-16', 'Shana Enterprises', 'Chennai', '6.00', '546.00', '30.00', 7.00, '7.00', '30 discount allowed'),
(9, 123456, '2021-12-16', 'ABC Enterprices', 'Kochi', '19.00', '0.47', '5.00', 19.47, '14.47', 'Updated invoice details'),
(13, 123456, '2021-12-17', 'DT Enterprises', 'Karnataka', '63.00', '6.00', '6986.68', 69.00, '62.00', '10% discount allowed');

-- --------------------------------------------------------

--
-- Table structure for table `invoice_order_item`
--

DROP TABLE IF EXISTS `invoice_order_item`;
CREATE TABLE IF NOT EXISTS `invoice_order_item` (
  `order_item_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `item_code` varchar(250) NOT NULL,
  `item_name` varchar(250) NOT NULL,
  `order_item_quantity` decimal(10,2) NOT NULL,
  `order_item_price` decimal(10,2) NOT NULL,
  `order_item_tax` decimal(10,2) NOT NULL,
  `order_item_final_amount` decimal(10,2) NOT NULL,
  PRIMARY KEY (`order_item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4409 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoice_order_item`
--

INSERT INTO `invoice_order_item` (`order_item_id`, `order_id`, `item_code`, `item_name`, `order_item_quantity`, `order_item_price`, `order_item_tax`, `order_item_final_amount`) VALUES
(4391, 8, '12', 'Pencils', '2.00', '300.00', '6.00', '600.00'),
(4392, 8, '30', 'Chocolates', '6.00', '200.00', '60.00', '1.00'),
(4393, 8, '04', 'Gold', '8.00', '600.00', '480.00', '4.00'),
(4394, 9, '01', 'Bag', '2.00', '1.00', '0.02', '2.00'),
(4395, 9, '02', 'Books', '3.00', '3.00', '0.45', '9.00'),
(4396, 9, '03', 'Textiles', '4.00', '2.00', '0.00', '8.00'),
(4406, 13, '17', 'Books', '20.00', '200.00', '200.00', '4.00'),
(4407, 13, '18', 'Dress', '12.00', '4899.00', '5.00', '58.00'),
(4408, 13, '09', 'Box', '10.00', '100.00', '0.00', '1.00');

-- --------------------------------------------------------

--
-- Table structure for table `invoice_user`
--

DROP TABLE IF EXISTS `invoice_user`;
CREATE TABLE IF NOT EXISTS `invoice_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `address` text NOT NULL,
  `admin_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=123457 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoice_user`
--

INSERT INTO `invoice_user` (`id`, `email`, `password`, `first_name`, `last_name`, `mobile`, `address`, `admin_status`) VALUES
(123456, 'user@invoice.com', '827ccb0eea8a706c4c34a16891f84e7b', 'Shana', 'Vijayan', 12345678912, 'New Delhi 110096 India.', 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
